# مخيمات الفارط API - MongoDB + Vercel

## الإعداد

### 1. MongoDB Atlas (مجاني)
- اذهب إلى mongodb.com/atlas
- أنشئ Cluster مجاني
- من Security → Database Access: أنشئ مستخدم وكلمة سر
- من Security → Network Access: أضف `0.0.0.0/0`
- من Clusters → Connect → Drivers: انسخ الـ Connection String

### 2. رفع البيانات لأول مرة
```bash
pip install pymongo
python sync.py --db /path/to/tent.db --uri "mongodb+srv://user:pass@cluster.mongodb.net/"
```

### 3. النشر على Vercel
- ارفع المشروع على GitHub
- اربطه بـ Vercel
- في Settings → Environment Variables أضف:
  ```
  MONGO_URI = mongodb+srv://user:pass@cluster.mongodb.net/
  DB_NAME   = makhayem
  ```

## Endpoints

| URL | الوصف |
|-----|-------|
| `/` | معلومات الـ API |
| `/api/bookings` | كل الحجوزات |
| `/api/bookings?date=2026-04-25` | حجوزات يوم محدد |
| `/api/bookings?from=2026-04-01&to=2026-04-30` | حجوزات فترة |
| `/api/camps` | المخيمات |
| `/api/customers` | الزبائن |
| `/api/report?from=2026-04-01&to=2026-04-30` | تقرير + إحصاء |

## تحديث البيانات
كل ما تريد تحديث البيانات من التطبيق، شغّل:
```bash
python sync.py --db /path/to/backup.db --uri "mongodb+srv://..."
```

## مثال رد
```json
GET /api/bookings?date=2026-04-25
{
  "count": 2,
  "bookings": [
    {
      "booking_id": 1,
      "customer": {"name": "أحمد البخراني", "phone": "0501234567"},
      "setup_date": "2026-04-22",
      "remove_date": "2026-04-28",
      "days": 7,
      "notes": "عزان",
      "camps": [{"name": "الأسطورة 30×10"}]
    }
  ]
}
```
